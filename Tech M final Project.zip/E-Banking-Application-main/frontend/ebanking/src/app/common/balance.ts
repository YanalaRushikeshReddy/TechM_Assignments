export class Balance {
    id: number;
    accountNo: number;
    balance: number;
    lastUpdate: Date;
}
