import { Mobilewithdraw } from './mobilewithdraw';

describe('Mobilewithdraw', () => {
  it('should create an instance', () => {
    expect(new Mobilewithdraw()).toBeTruthy();
  });
});
