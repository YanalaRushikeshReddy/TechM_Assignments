import { CardAccount } from './card-account';

describe('CardAccount', () => {
  it('should create an instance', () => {
    expect(new CardAccount()).toBeTruthy();
  });
});
