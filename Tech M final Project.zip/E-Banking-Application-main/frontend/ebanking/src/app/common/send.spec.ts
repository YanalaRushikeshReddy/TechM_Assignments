import { Send } from './send';

describe('Send', () => {
  it('should create an instance', () => {
    expect(new Send()).toBeTruthy();
  });
});
