import { Bankaccount } from './bankaccount';

describe('Bankaccount', () => {
  it('should create an instance', () => {
    expect(new Bankaccount()).toBeTruthy();
  });
});
