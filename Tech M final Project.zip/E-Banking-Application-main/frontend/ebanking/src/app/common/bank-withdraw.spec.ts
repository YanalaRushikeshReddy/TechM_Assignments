import { BankWithdraw } from './bank-withdraw';

describe('BankWithdraw', () => {
  it('should create an instance', () => {
    expect(new BankWithdraw()).toBeTruthy();
  });
});
