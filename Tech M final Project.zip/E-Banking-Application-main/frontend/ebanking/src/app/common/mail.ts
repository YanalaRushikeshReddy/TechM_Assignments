
export class Mail {
    to: string = "thinkingwholeworld@gmail.com";
    from: string;
    subject: string;
    body: string;
    sentDate: Date = new Date();
}
