import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unauthorizes',
  templateUrl: './unauthorizes.component.html',
  styleUrls: ['./unauthorizes.component.css']
})
export class UnauthorizesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
