package com.example.ebanking.entity;

public enum Role {
	USER, 
	ADMIN
}
