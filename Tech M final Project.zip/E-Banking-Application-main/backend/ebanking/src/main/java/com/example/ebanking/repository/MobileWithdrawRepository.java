package com.example.ebanking.repository;

import com.example.ebanking.entity.MobileWithdraw;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MobileWithdrawRepository extends JpaRepository<MobileWithdraw, Long> {
}
