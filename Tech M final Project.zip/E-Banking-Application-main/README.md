# E-Banking-Application
> A simple web app for try to learn advance technologies. 


## 🚨 Forking this repo (please read!)

Many people have contacted me asking me if they can use this code, and the answer to that question is usually **yes**.

I value keeping my application open source, but as you all know, _**plagiarism is bad**_. It's always disheartening whenever I find that someone has copied my application code without giving me credit. I spent a non-trivial amount of effort building and designing this iteration of my application, and I am proud of it! All I ask of you all is to not claim this effort as your own.

### Build with a brunch of things, name of few: 
- Spring Boot
- Spring Security
- JWT Authentication
- Spring Rest API
- Angular 10
- TypeScript
- Bootstrap 
and so on...

