package Exception_Handling;

public class PositiveException extends Exception{
public PositiveException(String message) {
	super(message);
}
}
