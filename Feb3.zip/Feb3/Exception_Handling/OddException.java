package Exception_Handling;

public class OddException extends Exception{
public OddException(String message) {
	super(message);
}
}
