package Exception_Handling;

public class EmptyException extends Exception{
public EmptyException(String message) {
	super(message);
}
}
